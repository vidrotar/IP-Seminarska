<!DOCTYPE>
<html>
<head>
	<title>MFIS</title>
    <script src="script.js"></script>
  	

  	<script src="./javaScript.js"></script> 
  	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>

</head>


<body onclick="prikaziRezultate()">

      <?php include 'povezava.php';?> <!-- povezava z bazo -->


<input type="text" name="vprasalnik"  value="MSQOL-54">


<!-- IZPISI ANKETO: -->
<?php
	$id_vprasanje = 22;
	$steviloMoznihOdgovorov = "SELECT count(*)  FROM odgovor o ,vprasanje v where o.id_vprasanje=v.id_vprasanje and o.id_vprasanje = 22 ";
	$r = $conn->query($steviloMoznihOdgovorov);
	while ($row = $r->fetch_assoc()) {
    	$steviloMoznihOdgovorov = $row['count(*)']."<br>";
	}
	echo 'stevilo moznih odgovorov na vprasanje = ' . $steviloMoznihOdgovorov . '</br>';



	$sql = "SELECT * FROM odgovor o ,vprasanje v where o.id_vprasanje=v.id_vprasanje and o.id_vprasanje = 22 ";
	$result = $conn->query($sql);
	echo '
		<div id="page-wrap">
			<h1>PRILAGOJENA LESTVICA VPLIVA UTRUJENOSTI MODIFIED FATIGUE IMPACT SCALE (MFIS)*</h1>
				<form action="grade.php" method="post" id="quiz">
				<p> EMSO: <input type="text" name="emso"  value="12345"></p><br>
				<p>DATUM:<input type="date" name="datum"> </p>
		';

	$result->num_rows;
	$row = $result->fetch_assoc();
	echo '<h3> Vprasanje = | '. 'id:' . $row["id_vprasanje"] .' vprasanje text:'. $row["vprasanje"] .  '| </h3>  ';

	if ($result->num_rows > 0) {
	    while($row = $result->fetch_assoc()) {
	    	echo '<h5>  ' .  'mozen odgovor:'. $row["opis"] .' </h5>';
	    }
	    echo '
           		<input type="submit" value="Oddaj" />
			</form>
		</div>
	    ';
	    
	} else {
	    echo "0 results";
	}


?> 



</body>
</html>