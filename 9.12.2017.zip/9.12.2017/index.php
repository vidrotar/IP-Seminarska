<!DOCTYPE>
<html>
<head>
	<title>MFIS</title>
    <script src="script.js"></script>
	<link rel="stylesheet" type="text/css" href="css.css" />
  	

  	<script src="./javaScript.js"></script> 
  	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>



</head>
<!-- <body onload="onLoad(1,2)"> -->
	<!-- blaJa -->

<div style="color: red">
	<h1>NE KLIKUJ GUMBA "ODDAJ"</h1>
	
</div>

<body onclick="prikaziRezultate()">

      <?php include 'pisiVkonzolo.php';?> <!-- za pisanje v konzolo -->
      <?php include 'povezava.php';?> <!-- povezava z bazo -->


<!-- IZPISI ANKETO: -->
<?php
	$sql = "SELECT * FROM vprasanja";
	$result = $conn->query($sql);
	echo '
		<div id="page-wrap">
			<h1>PRILAGOJENA LESTVICA VPLIVA UTRUJENOSTI MODIFIED FATIGUE IMPACT SCALE (MFIS)*</h1>
				<form action="grade.php" method="post" id="quiz">
				<p> EMSO: <input type="text" name="emso"  value="12345"></p><br>
				<p>DATUM:<input type="date" name="datum"> </p>
            		<ol>
		';
	if ($result->num_rows > 0) {
	    $i=1;
	    while($row = $result->fetch_assoc()) {
	    	echo '<li>';
	    	echo '<h3>  ' . $row["vprasanje"] .  '</h3>';
	        echo '<div>		<input type="radio" name="' . $row["id"]. '" id="odgovor' . $row["id"] . 'odgovorA" value="1" />	<label> NIKOLI 			</label>		</div>';
	        echo '<div>		<input type="radio" name="' . $row["id"]. '" id="odgovor' . $row["id"] . 'odgovorB" value="2" />	<label> REDKO 			</label>		</div>';
	        echo '<div>		<input type="radio" name="' . $row["id"]. '" id="odgovor' . $row["id"] . 'odgovorC" value="3" />	<label> VČASIH			</label>		</div>';
	        echo '<div>		<input type="radio" name="' . $row["id"]. '" id="odgovor' . $row["id"] . 'odgovorD" value="4" />	<label> POGOSTO 		</label>		</div>';
	        echo '<div>		<input type="radio" name="' . $row["id"]. '" id="odgovor' . $row["id"] . 'odgovorE" value="5" checked="checked"/>	<label> SKORAJ VEDNO 	</label></div>';
	        echo '</li>';
	        $i++;
	    }
	    echo '
            		</ol>
           		<input type="submit" value="Oddaj" />
			</form>
		</div>
	    ';
	    
	} else {
	    echo "0 results";
	}


?> 
<!-- ! IZPISI ANKETO -->

<p><b>REZULTATI(kaj si oznacil):</b> <span id="rezultati"></span></p>
	<button id="obdelavaPodatkov" > Obdelaj podatke </button>

<?php
	// echo "VPRASANJA KATEGIRIJE 1 (Telesna podlestvica)";
	echo '<div id="telesna" hidden>';
	$telesnaID = array();
	// print_r($stack);
	$sqlPoizvedba = "SELECT * FROM vprasanja where kategorija = 1";
	$rezultatiPoizvdbe = $conn->query($sqlPoizvedba);
	if ($rezultatiPoizvdbe->num_rows > 0) {
		$i=0;
	    while($row = $rezultatiPoizvdbe->fetch_assoc()) {
	    	// echo '<div>  id=' . $row["id"] . ' vprasanje=' . $row["vprasanje"] . ' kategorija=' . $row["kategorija"] . ' </div>'; 
			array_push($telesnaID, $row["id"]);
	    	$i++;
	    }
	}
	echo implode(" ",$telesnaID);
	echo '</div>';

	// echo "VPRASANJA KATEGIRIJE 2 (Kognitivna podlestvica)";
	echo '<div id="kognitivna" hidden>';
	$kognitivnaID = array();
	$sqlPoizvedba = "SELECT * FROM vprasanja where kategorija = 2";
	$rezultatiPoizvdbe = $conn->query($sqlPoizvedba);
	if ($rezultatiPoizvdbe->num_rows > 0) {
		$i=0;
	    while($row = $rezultatiPoizvdbe->fetch_assoc()) {
	    	// echo '<div>  id=' . $row["id"] . ' vprasanje=' . $row["vprasanje"] . ' kategorija=' . $row["kategorija"] . ' </div>'; 
			array_push($kognitivnaID, $row["id"]);
	    	$i++;
	    }
	}
	echo implode(" ",$kognitivnaID);
	echo '</div>';
	

	// echo "VPRASANJA KATEGIRIJE 3 (Psihosocialna podlestvica)";
	echo '<div id="psihosocialna" hidden>';
	$psihosocialnaID = array();
	$sqlPoizvedba = "SELECT * FROM vprasanja where kategorija = 3";
	$rezultatiPoizvdbe = $conn->query($sqlPoizvedba);
	if ($rezultatiPoizvdbe->num_rows > 0) {
		$i=0;
	    while($row = $rezultatiPoizvdbe->fetch_assoc()) {
	    	// echo '<div>  id=' . $row["id"] . ' vprasanje=' . $row["vprasanje"] . ' kategorija=' . $row["kategorija"] . ' </div>'; 
			array_push($psihosocialnaID, $row["id"]);
	    	$i++;
	    }
	}
	echo implode(" ",$psihosocialnaID);
	echo '</div>';

	// echo '<script type="text/javascript">',
 //     'obdelavaPodatkov();',
 //     '</script>'
	// ;



	

?>



<div id="objavaRezultatov" style="color: red">
</div>


</br></br></br></br></br></br></br></br></br>



<style type="text/css">
div.inline { float:left; }
.clearBoth { clear:both; }
</style>

</body>
</html>